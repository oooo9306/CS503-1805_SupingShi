import argparse #invoke arguments 
import atexit #release reserved resource when exit
import json #network data is json format
import logging #print status
import requests #invoke http API
import schedule #control frequency to invoke
import time #used to produce time stamps

#import kafka things
from kafka import KafkaProducer
from kafka.errors import KafkaError

#current OS time - print OS time, good for DS
logger_format = "%(asctime)s - %(message)s" 
#set up the format of log
logging.basicConfig(format=logger_format)
#create a log instance 
logger = logging.getLogger('data-producer')
#set the level of log, DEBUG is very low level
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler('logger.log')
fh.setLevel(logging.DEBUG)
logger.addHandler(fh)

#create a API constant
API_BASE = 'https://api.gdax.com'

def check_symbol(symbol):
	"""
	helper method to check if the symbol exists in coinbase API
	"""
	logger.debug('Checking symbol.')
	try:
		response = requests.get(API_BASE + '/products') #import request package to send a get request to 'http://api.gdax.com/products'
		product_ids = [product['id'] for product in response.json()] #it is a loop to get the whole product list
		if symbol not in product_ids: #check if symbol is not in list, print out a warn
			logger.warning('Symbol %s is not supported. This list of supported symbols : %s', symbol, product_ids)
			exit()#trigger an exit() method to release resource
	except Exception as e: #throw an exception. cause almost network communications will throw out some exceptions.
		logger.warning('Failed to fecth products: %s', e) 

def fetch_price(symbol, producer, topic_name):
	"""
	helper function to retrieve asset data and send it to kafka
	"""
	logger.debug('start to fetch price for %s', symbol)
	try:
		response = requests.get('%s/products/%s/ticker' % (API_BASE, symbol))#same aim in check_sum() function
		price = response.json()['price']
		timeStamp = time.time()

		#create a json structure of fectched price data
		payload = {
			'Symbol':str(symbol),
			'lastTradePrice':str(price),
			'timeStamp':str(timeStamp)
		}

		logger.debug('Retrieved %s info %s', symbol, payload)

		#send payload to kafka, value must string, so we need to trasfer json to string and encode it 
		producer.send(topic=topic_name, value=json.dumps(payload).encode('utf-8'))
		logger.debug('Sent price for %s to Kafka', symbol)

	except Exception as e:
		logger.warning('Failed to fetch price: %s', e)


def shutdown_hook(producer):
	"""
	a shutdown hook to be called refresh producer by flushing all data in buffer before the shut down.
	"""
	try:
		logger.info('Flushing pending messages to kafka, timeout is set to 10s') 
		producer.flush(10)#flushing in 10 seconds
	except KafkaError as kafka_error:
		logger.warning('Failed to flush pending messages to kafka, caused by: %s', kafka_error.message)
	finally:
		try:
			logger.info('Closing kafka connection') 
			producer.close(10)
		except Exception as e:
			logger.warning('Failed to close Kafka connection, caused by: %s', e.message)



#create a main function, if other invoke my program will not run this
if __name__ == '__main__':
	parser = argparse.ArgumentParser() #get arguments from users
	parser.add_argument('symbol', help = 'the symbol you want to pull') #category of currency
	parser.add_argument('topic_name', help = 'the kafka topic push to') #kafka queue
	parser.add_argument('kafka_broker', help = 'the location of kafka broker') #locate position ifn kafka

	#read the arguments passed by user and become the type we want from string
	args = parser.parse_args()
	symbol = args.symbol
	topic_name = args.topic_name
	kafka_broker = args.kafka_broker

	#after we have the argument symbol, we need to check whether it is valid
	#write a function, check_symbol
	check_symbol(symbol)

	#instantiate a kafka producer
	#refer to python kafka example on kafka offical website
	#we use fetch_price function as actual producer to fetch raw data to kafka
	producer = KafkaProducer(bootstrap_servers=kafka_broker)

	#schedule and run the fetch_price function per second
	#topic_name is use to confirm which queue to process
	schedule.every(1).second.do(fetch_price, symbol, producer, topic_name)

	#set up a shutdown hook
	#relese reserved resouces when we exit program
	#that resoucers here is producer we use
	atexit.register(shutdown_hook, producer)

	while True:
		#run schedule once and sleep a second. then do loop
		schedule.run_pending()
		time.sleep(1) #it cause busy waiting if we don't sleep. 



 

